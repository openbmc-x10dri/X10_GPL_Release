

#ifndef WSMAN_UUID_H
#define WSMAN_UUID_H

#define MAC_LEN 6
#define SIZE_OF_UUID_STRING     37

int generate_uuid (char* buf, int size, int bNoPrefix);


#endif
