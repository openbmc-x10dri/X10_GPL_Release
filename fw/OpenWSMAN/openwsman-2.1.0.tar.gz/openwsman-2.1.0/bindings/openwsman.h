

#ifndef OPENWSMAN_H_SWIG_
#define OPENWSMAN_H_SWIG_

void init_pywsman(void);
void debug_message_handler (const char *str, debug_level_e level, void *user_data);

#endif
