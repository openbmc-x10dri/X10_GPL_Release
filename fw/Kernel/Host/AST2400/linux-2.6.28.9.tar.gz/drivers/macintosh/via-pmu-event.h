#ifndef __VIA_PMU_EVENT_H
#define __VIA_PMU_EVENT_H

#define PMU_EVT_POWER	0
#define PMU_EVT_LID	1
extern void via_pmu_event(int key, int down);

#endif /* __VIA_PMU_EVENT_H */
