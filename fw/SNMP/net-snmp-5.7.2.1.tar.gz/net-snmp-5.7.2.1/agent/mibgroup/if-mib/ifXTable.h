/*
 * module to include the modules
 */

config_require(if-mib/ifXTable/ifXTable)

