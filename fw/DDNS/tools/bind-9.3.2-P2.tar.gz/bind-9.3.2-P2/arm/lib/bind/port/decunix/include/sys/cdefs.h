#define __BEGIN_DECLS
#define __END_DECLS
#define __P(x) x
#define __dead
#define __pure
#define __attribute__(x)
