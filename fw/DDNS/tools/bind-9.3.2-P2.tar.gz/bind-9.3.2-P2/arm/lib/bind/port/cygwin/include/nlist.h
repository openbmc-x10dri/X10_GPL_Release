#ifndef NLIST_H
#define NLIST_H		1

/* Dummy include for CYGWIN */

#endif
