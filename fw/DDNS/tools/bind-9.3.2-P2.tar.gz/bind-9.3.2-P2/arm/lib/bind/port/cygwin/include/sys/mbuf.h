#ifndef MBUF_H
#define MBUF_H		1

/* Dummy include for CYGWIN */

#endif
