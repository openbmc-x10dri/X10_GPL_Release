#!/bin/bash

[ -f /bin/module/bonding.ko ] && insmod /bin/module/bonding.ko miimon=100 mode=1

[ ! -f /nv/resolv.conf ] && touch /nv/resolv.conf

#IPv6 setting
if [ ! -d "/nv/network" ]; then
    mkdir /nv/network
fi

if [ ! -f "/nv/network/netconfig0" ]; then
#eth0
    cp /etc/network/netconfig.default /nv/network/netconfig0
fi
if [ ! -f "/nv/network/netconfig1" ]; then
#eth1
   cat /etc/network/netconfig.default | sed -e 's/0=/1=/g' -e 's/eth0/eth1/g' > /nv/network/netconfig1
fi
if [ ! -f "/nv/network/netconfig2" ]; then
#bond0
   cat /etc/network/netconfig.default | sed -e 's/0=/2=/g' -e 's/eth0/bond0/g' > /nv/network/netconfig2
fi

#Network firewall
if [ ! -d "/nv/ipctrl" ]; then
	mkdir -p /nv/ipctrl
else
	if [ -f "/nv/ipctrl/rultbl.sav" ]; then
		/sbin/iptables-restore < /nv/ipctrl/rultbl.sav
	fi
fi

#DDNS env [start]
if [ -d "/usr/local/etc/ddns/tmp" ]
then
if [ ! -d /nv/ddns ]; then mkdir /nv/ddns ; fi
cd /usr/local/etc/ddns/tmp
if [ ! -f /nv/ddns/DDNS_CONFIG ]; then cp ./DDNS_CONFIG /nv/ddns/  ; fi
if [ ! -f /nv/ddns/ddns.key ]; then cp ./ddns.key /nv/ddns/  ; fi
if [ ! -f /nv/ddns/ddns.private ]; then cp ./ddns.private /nv/ddns/  ; fi
fi

if [ ! -f /nv/bmc_hostname ]; then echo "localhost" > /nv/bmc_hostname  ; fi
if [ ! -f /nv/hostname_for_dhcp ]; then touch /nv/hostname_for_dhcp; fi
#DDNS env [end]

#NTP env [start]
if [ -d /usr/local/etc/ntp ]
then
    if [ ! -d /nv/ntp ]; then mkdir /nv/ntp ; fi
    if [ ! -f /nv/ntp/ntp.conf ]; then cp /usr/local/etc/ntp/ntp.conf /nv/ntp/ntp.conf ; fi
	if [ ! -f /nv/timezone ]; then echo "0" > /nv/timezone ; fi	
fi
#NTP env [end]


#copy  enSSL.config for LDAP and AD
if [ ! -f /nv/enSSL.config ]
then 
cp /etc/defaults/enSSL.config /nv/
fi

#SNMP env [start]
if [ ! -f /nv/snmpd.conf ]
then 
cp /etc/defaults/snmpd.conf /nv/
fi
#SNMP env [end]
