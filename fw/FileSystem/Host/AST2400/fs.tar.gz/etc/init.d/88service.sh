#!/bin/sh


/etc/init.d/httpd start
/etc/init.d/sfcb   start
/etc/init.d/openwsmand start
/etc/init.d/net-snmpd start
/etc/init.d/slogd start
/etc/init.d/ipfw start

touch /tmp/datetime_sem_tmp

[ -d /nv/ntp ] && /bin/ntp_service.sh &
/etc/init.d/smashd start&

/etc/init.d/stunneld start

