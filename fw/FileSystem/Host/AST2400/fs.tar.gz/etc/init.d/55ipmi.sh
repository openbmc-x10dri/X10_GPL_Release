#!/bin/bash

[ -f /bin/module/ikvm_vmass.ko ] && /sbin/insmod /bin/module/ikvm_vmass.ko
[ -f  /bin/module/video_drv.ko ] && /sbin/insmod /bin/module/video_drv.ko
[ -f /bin/module/usb_hid.ko ] && /sbin/insmod /bin/module/usb_hid.ko

cd /bin
./sysinit
./oob_task&
ifconfig lo up
./LanNotifier&

if [ -f /bin/module/ikvm_vmass.ko ]; then
  /etc/init.d/vmd start
fi

if [ -f /bin/module/video_drv.ko ]; then
  /etc/init.d/ikvmd start
fi
