#!/bin/sh


mount -t tmpfs /tmp -o size=42m
mount -t proc /proc
mount -a
if [ -f /etc/init.d/udev ]; then
	. /etc/init.d/udev start
fi

mount -t jffs2 /dev/mtdblock1 /nv >/dev/null 2>&1
if [ $? -ne 0 ];then
echo "format partition......"
	flash_erase /dev/mtd1 0 0
	mount -t jffs2 /dev/mtdblock1 /nv
fi

cp /bin/busybox /tmp
mount -t cramfs /dev/mtdblock4 /web
