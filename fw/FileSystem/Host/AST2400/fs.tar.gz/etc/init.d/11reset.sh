#!/bin/bash
[ -f /nv/reset_to_default ] && /bin/restore_file.sh 1
