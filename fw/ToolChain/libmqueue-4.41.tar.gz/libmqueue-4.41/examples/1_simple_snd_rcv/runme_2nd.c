/*
*  EXAMPLE for POSIX message queues implementation in Linux.
*
*  This program opens existing message queue, receives a message from it, 
*  deletes queue and  exits.
*
*  Author: 		Krzysztof Benedyczak
*
*  This file is under GPL licence.
*/ 

#include <stdio.h>
#include <mqueue.h>


#define QUEUE_NAME 	"/example_queue_1"
#define SIZE		256

int main(int argc, char ** argv)
{
	mqd_t ds;
	char text[SIZE];
	int prio;

	/* This opens a queue named "/example_queue_1" for receiving messages only. 
	 * Queue is opened in blocking mode. */
	ds = mq_open(QUEUE_NAME, O_RDONLY);
	if (ds == -1)
	{
		perror("Opening queue error");
		exit(1);
    	}

	puts("Message queue opened");
	
	/* Now receive 1 message from a queue to text, and its priority to prio*/
	if (mq_receive(ds, text, SIZE, &prio) == -1)
	{
		perror("Receiving message error");
		return -1;
	} else	
		printf("Message received:\n %s\n It's priority was: %i\n", text, prio);
	
	/* Close queue... */	
	if (mq_close(ds) == -1)
		perror("Closing queue error");
	else
		puts("Message queue closed");
	
	/* ...and finally unlink it. After unlink message queue is removed from system. */
	if (mq_unlink(QUEUE_NAME) == -1)
		perror("Removing queue error");
	return 0;
}


