/*
*  EXAMPLE for POSIX message queues implementation in Linux.
*
*  This program simply sends one message to a queue.
*
*  Author: 		Krzysztof Benedyczak
*
*  This file is under GPL licence.
*/ 

#include <mqueue.h>

#define QUEUE_NAME 	"/example_queue_5"
#define PRIO 		1

int main(int argc, char ** argv)
{
	mqd_t ds;
	char text[] = "Our message body: Hello message!";

	/* This opens a queue named "/example_queue_1" for 
	 * sending messages only. */
	ds = mq_open(QUEUE_NAME, O_WRONLY);
	if (ds == -1)
	{
		perror("Opening queue error");
		exit(1);
    	}

	/* It just sends message to a queue, with priority 1 */
	if (mq_send(ds, text, strlen(text), PRIO) == -1)
		perror("Sending message error");
	else	
		puts("Message sent to queue");
	return 0;
}

