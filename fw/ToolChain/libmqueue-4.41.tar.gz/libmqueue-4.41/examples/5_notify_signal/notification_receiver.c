/*
*  EXAMPLE for POSIX message queues implementation in Linux.
*
*  Program creates queue, set signal notification and waits for it.
*  After getting notification it will receive message and remove queue.
*
*  Author: 		Krzysztof Benedyczak
*
*  This file is under GPL licence.
*/ 

#include "mqueue.h"


#define QUEUE_NAME 	"/example_queue_5"
#define SIZE		256

int main(int argc, char ** argv)
{
	mqd_t ds;
	char text[SIZE];
	int prio;
	struct mq_attr queue_attr;
	struct sigevent notif;
	sigset_t sig_set;
	siginfo_t info;

	/* Attributes for our queue. Those can be set only during creating. */
	queue_attr.mq_maxmsg = 32;	/* max. number of messages in queue at the same time */
	queue_attr.mq_msgsize = 256;	/* max. message size */

	/* This creates a new queue named "/example_queue_1" and opens it for 
	 * receiving messages only. If the queue with the same name already exists 
	 * function should fail (O_EXCL). The queue file permissions are set rw for owner 
	 * and nothing for group/others. Queue limits set to values provided above. */
	ds = mq_open(QUEUE_NAME, O_CREAT | O_RDONLY | O_EXCL, 0600, &queue_attr);
	if (ds == -1)
	{
		perror("Creating queue error");
		exit(1);
    	}

	puts("Message queue created & opened");

	/* We must block notification signal (notification can happen just after mq_notify
	 * and before sigwaitinfo. */
	sigemptyset(&sig_set);
	sigaddset(&sig_set, SIGUSR1);
	sigprocmask(SIG_BLOCK, &sig_set, NULL);

	/* Now set notification. We want to get SIGUSR1 when the message will arrive to 
	 * (empty) queue. */
	notif.sigev_notify = SIGEV_SIGNAL;
	notif.sigev_signo = SIGUSR1;
    
    	if (mq_notify(ds, &notif))
	{
		perror("mq_notify");
		return -1;
	}
    
	puts("Notification SIGEV_SIGNAL established");

	puts("Waiting...");    
	do 
	{
		sigwaitinfo(&sig_set, &info);	
		printf("Got %i signal\n", info.si_signo);
	} while(info.si_signo != SIGUSR1);

	/* Now of course we can receive this message. */
	if (mq_receive(ds, text, SIZE, &prio) == -1)
		perror("Receiving message error");
	else	
		printf("Message received:\n %s\n It's priority was: %i\n", text, prio);
	
	if (mq_close(ds) == -1)
		perror("Closing queue error");
	else
		puts("Message queue closed");

	if (mq_unlink(QUEUE_NAME) == -1)
		perror("Removing queue error");	
	return 0;
}


