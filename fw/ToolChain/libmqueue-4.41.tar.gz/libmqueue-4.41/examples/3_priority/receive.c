/*
*  EXAMPLE for POSIX message queues implementation in Linux.
*
*  This program opens existing message queue, receives 10 message from it
*  showing priorities, deletes queue and  exits.
*
*  Author: 		Krzysztof Benedyczak
*
*  This file is under GPL licence.
*/ 

#include <stdio.h>
#include <mqueue.h>


#define QUEUE_NAME 	"/example_queue_3"
#define SIZE		256

int main(int argc, char ** argv)
{
	mqd_t ds;
	char text[SIZE];
	int prio, i;

	/* This opens a queue named "/example_queue_3" for receiving messages only. 
	 * Queue is opened in blocking mode. */
	ds = mq_open(QUEUE_NAME, O_RDONLY);
	if (ds == -1)
	{
		perror("Opening queue error");
		exit(1);
    	}

	puts("Message queue opened");
	
	/* Now receive 10 messages from a queue to text*/
	for (i=0; i<10; i++)
		if (mq_receive(ds, text, SIZE, &prio) == -1)
		{
			perror("Receiving message error");
			return -1;
		} else	
			printf("Message received; it's priority was: %i\n", prio);
	
	/* Close queue... */	
	if (mq_close(ds) == -1)
		perror("Closing queue error");
	else
		puts("Message queue closed");
	
	/* ...and finally unlink it. After unlink message queue is removed from system. */
	if (mq_unlink(QUEUE_NAME) == -1)
		perror("Removing queue error");
	return 0;
}


