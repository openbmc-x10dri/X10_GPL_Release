/*
*  EXAMPLE for POSIX message queues implementation in Linux.
*
*  This program creates message queue, sends 10 messages to it 
*  with randowm priorities and exits.
*
*  Author: 		Krzysztof Benedyczak
*
*  This file is under GPL licence.
*/ 

#include <mqueue.h>


#define QUEUE_NAME 	"/example_queue_3"
#define SIZE		256

int main(int argc, char ** argv)
{
	mqd_t ds;
	char text[] = "Our message body: Hello message!";
	struct mq_attr queue_attr;
	int i;

	/* Attributes for our queue. Those can be set only during creating. */
	queue_attr.mq_maxmsg = 32;	/* max. number of messages in queue at the same time */
	queue_attr.mq_msgsize = SIZE;	/* max. message size */

	/* This creates a new queue named "/example_queue_1" and opens it for 
	 * sending messages only. If the queue with the same name already exists 
	 * function should fail (O_EXCL). The queue file permissions are set rw for owner 
	 * and nothing for group/others. Queue limits set to values provided above. */
	ds = mq_open(QUEUE_NAME, O_CREAT | O_WRONLY | O_EXCL, 0600, &queue_attr);
	if (ds == -1)
	{
		perror("Creating queue error");
		exit(1);
    	}

	puts("Message queue created & opened");
	
	/* sends messages to a queue */
	srand(time(NULL));
	for (i=0; i<10; i++)
		if (mq_send(ds, text, strlen(text), rand()%100) == -1)
			perror("Sending message error");
		else	
			printf("Message no %i sent to queue\n", i);
		
	/* This isn't needed here as we are exiting in a moment. But as it 
	 * is example: the following line closes message queue (ds is invalid 
	 * after mq_close(). */
	if (mq_close(ds) == -1)
		perror("Closing queue error");
	else
		puts("Message queue closed");
	return 0;
}

