/*
*  EXAMPLE for POSIX message queues implementation in Linux.
*
*  This program creates message queue in nonblocking mode, 
*  gets its attributes, then removes nonblocking mode and again 
*  gets its attributes. So in short mq_setattr/mq_getattr example.
*
*  Author: 		Krzysztof Benedyczak
*
*  This file is under GPL licence.
*/ 

#include <mqueue.h>


#define QUEUE_NAME 	"/example_queue_4"

/* Converts int arg with queues flags into human readible form. */
void read_flags(char *flagstr, int oflag)
{
	strcpy(flagstr,"");
	if (oflag & O_RDWR) 
		strcat(flagstr,"O_RDWR ");
	else 
		if (oflag & O_WRONLY) 
			strcat(flagstr,"O_WRONLY ");
		else 
			strcat(flagstr,"O_RDONLY ");
	if (oflag & O_CREAT) 
		strcat(flagstr,"O_CREAT ");	    
	if (oflag & O_EXCL) 
		strcat(flagstr,"O_EXCL ");
	if (oflag & O_NONBLOCK) 
		strcat(flagstr,"O_NONBLOCK ");
}



int main(int argc, char ** argv)
{
	mqd_t ds;
	struct mq_attr attr, old_attr;
	char flag[80];

	/* Attributes for our queue. Those can be set only during creating. */
	attr.mq_maxmsg = 32;	/* max. number of messages in queue at the same time */
	attr.mq_msgsize = 256;	/* max. message size */

	/* This creates a new queue named "/example_queue_3" in nonblocking mode. 
	 * and nothing for group/others. Queue limits set to values provided above. 
	 * If the queue exists the function will fail. */
	ds = mq_open(QUEUE_NAME, O_CREAT | O_RDWR | O_EXCL | O_NONBLOCK, 0600, &attr);
	if (ds == -1)
	{
		perror("Creating queue error");
		exit(1);
    	}

	puts("Message queue created & opened");
	
	attr.mq_flags = 0;
	/* set !O_NONBLOCK, and also store old attributes into old_attr */
	if (mq_setattr(ds, &attr, &old_attr))
	{
		perror("mq_setattr");
		return -1;
    	}
	/* convert to string */
	read_flags(flag,old_attr.mq_flags);
	printf("Orginal queue flags: %s\n", flag);
	
	/* Here we will convince ourself that O_NONBLOCK is not set. */
	if (mq_getattr(ds, &old_attr))
	{
		perror("mq_getattr");
		return -1;
	}
	
	/* NOTE: other fields (e.g. number of messages) of struct mq_attr
	 * are also fetched! You can use them but not set. Limits are set 
	 * upon creating queue, and message count is set implicitly
	 * by sending/receiving messages. */
	
	read_flags(flag, old_attr.mq_flags);    
	printf("After setting blocking mode: %s\n",flag);

	/* Close queue... */	
	if (mq_close(ds) == -1)
		perror("Closing queue error");
	else
		puts("Message queue closed");
	
	/* ...and finally unlink it. After unlink message queue is removed from system. */
	if (mq_unlink(QUEUE_NAME) == -1)
		perror("Removing queue error");
	return 0;
}

