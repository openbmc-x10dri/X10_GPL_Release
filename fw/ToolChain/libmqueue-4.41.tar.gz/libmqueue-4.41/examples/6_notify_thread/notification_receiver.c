/*
*  EXAMPLE for POSIX message queues implementation in Linux.
*
*  Program creates queue, set signal notification and waits for it.
*  After getting notification it will receive message and remove queue.
*
*  Author: 		Krzysztof Benedyczak
*
*  This file is under GPL licence.
*/ 

#include "mqueue.h"


#define QUEUE_NAME 	"/example_queue_6"
#define SIZE 		256

volatile int finish = 0;

/* This is the function we want to run when the notification will occur.
 * It will be run in separate thread (as it's sttart function) */
void thread_notify_routine(sigval_t value)
{
	char text[SIZE];
	int prio, len;

	printf("Thread notification occured with arg %i\n", value);
	/* now of course we can receive this message. How to do this
	 * you should know already */
	if ((len = mq_receive(value.sival_int, text, SIZE, &prio)) == -1)
		perror("Receiving message error");
	else {
		text[len] = '\0';
		printf("Message received:\n %s\n It's priority was: %i\n", text, prio);
	}
	finish = 1;
}



int main(int argc, char ** argv)
{
	mqd_t ds;
	struct mq_attr queue_attr;
	struct sigevent notif;
	sigset_t sig_set;
	siginfo_t info;

	/* Attributes for our queue. Those can be set only during creating. */
	queue_attr.mq_maxmsg = 32;	/* max. number of messages in queue at the same time */
	queue_attr.mq_msgsize = SIZE;	/* max. message size */

	/* This creates a new queue named "/example_queue_1" and opens it for 
	 * receiving messages only. If the queue with the same name already exists 
	 * function should fail (O_EXCL). The queue file permissions are set rw for owner 
	 * and nothing for group/others. Queue limits set to values provided above. */
	ds = mq_open(QUEUE_NAME, O_CREAT | O_RDONLY | O_EXCL, 0600, &queue_attr);
	if (ds == -1)
	{
		perror("Creating queue error");
		exit(1);
    	}

	puts("Message queue created & opened");

	/* Now set SIGEV_THREAD notification. */
	notif.sigev_notify = SIGEV_THREAD;
	notif.sigev_notify_function = thread_notify_routine;
	notif.sigev_value.sival_int = ds;	/* This value of parameter for notification routine */
	notif.sigev_notify_attributes = NULL;	/* it means that notification thread will be DETACHED */
						/* (other attributes will be set to defaults) */
    	if (mq_notify(ds, &notif))
	{
		perror("mq_notify");
		return -1;
	}
    
	puts("Notification SIGEV_THREAD established");

	puts("Waiting...");
	do 
	{
		sleep(1);
	} while(finish == 0);
	puts("Waiting finished");

	if (mq_close(ds) == -1)
		perror("Closing queue error");
	else
		puts("Message queue closed");

	if (mq_unlink(QUEUE_NAME) == -1)
		perror("Removing queue error");	
	return 0;
}


