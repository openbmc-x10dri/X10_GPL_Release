/*
*  EXAMPLE for POSIX message queues implementation in Linux.
*
*  This program open message queue (if it doesn't exist it will be created). 
*  Next it tries to receive a message from it for 10 seconds. If the message 
*  will be in queue in that time, programm will remove queue. Otherwise it will simply 
*  exit.
*
*  Author: 		Krzysztof Benedyczak
*
*  This file is under GPL licence.
*/ 

#include <stdio.h>
#include <mqueue.h>
#include <errno.h>

#define QUEUE_NAME 	"/example_queue_2"
#define SIZE		256

int main(int argc, char ** argv)
{
	mqd_t ds;
	char text[SIZE];
	int prio;
	struct mq_attr queue_attr;
	struct timespec ts;

	/* Attributes for our queue. Those can be set only during creating. */
	queue_attr.mq_maxmsg = 32;	/* max. number of messages in queue at the same time */
	queue_attr.mq_msgsize = SIZE;	/* max. message size */

	/* This creates a new queue named "/example_queue_1" and opens it for 
	 * sending messages only. The queue file permissions are set rw for owner 
	 * and nothing for group/others. Queue limits set to values provided above. 
	 * If the queue exists it will be just opened. */
	ds = mq_open(QUEUE_NAME, O_CREAT | O_RDONLY, 0600, &queue_attr);
	if (ds == -1)
	{
		perror("Creating/opening queue error");
		exit(1);
    	}

	puts("Message queue opened");
	
	/* Now receive 1 message from a queue to text, and its priority to prio. We set timeout
	 * to 10 seconds from now. Note that timeout is absolute!!! */
	ts.tv_sec = time(NULL) + 10;
	ts.tv_nsec = 0; 
	
	puts("Waiting for message (10 sec) ..."); 
	if (mq_timedreceive(ds, text, SIZE, &prio, &ts) == -1)
	{
		if (errno == ETIMEDOUT)
		{
			puts("Timeout expired when waiting for message.");
			puts("Try to rerun program and send message to queue.");
			return 0;
		}
		perror("Receiving message error");
		return -1;
	}
	
	printf("Message received:\n %s\n It's priority was: %i\n", text, prio);
	
	/* Close queue... */	
	if (mq_close(ds) == -1)
		perror("Closing queue error");
	else
		puts("Message queue closed");
	
	/* ...and finally unlink it. After unlink message queue is removed from system. */
	if (mq_unlink(QUEUE_NAME) == -1)
		perror("Removing queue error");
	return 0;
}


