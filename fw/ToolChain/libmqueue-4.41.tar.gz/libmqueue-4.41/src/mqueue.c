/*
   mqueue.c - POSIX message queues library
 
   Copyright (C) 2003,2004 Krzysztof Benedyczak (golbi@mat.uni.torun.pl)
 			   Michal Wronski       (wrona@mat.uni.torun.pl)

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   It is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this software; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

#define _XOPEN_SOURCE 600

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <stdio.h>
#include <limits.h>
#if !defined(PATH_MAX)
#include <linux/limits.h>
#endif
#include <stdarg.h>
#include <errno.h>
#include <string.h>
#include <poll.h>

#include "../include/mqueue.h"
#include "config.h"

#ifndef __NR_mq_open

#ifdef __i386__
#define __NR_mq_open		277
#elif defined __x86_64__
#define __NR_mq_open		240
#else
#error unsupported architecture
#endif

#define __NR_mq_unlink		(__NR_mq_open+1)
#define __NR_mq_timedsend	(__NR_mq_open+2)
#define __NR_mq_timedreceive	(__NR_mq_open+3)
#define __NR_mq_notify		(__NR_mq_open+4)
#define __NR_mq_getsetattr	(__NR_mq_open+5)
#endif

#ifdef SIGEVTHREAD_SUPPORT
#include <pthread.h>

/*
 * Force any references in this file to the following externs to
 * define to NULL if global definitions cannot be found at link
 * edit time.
 */

#pragma weak pthread_create
#pragma weak pthread_sigmask
#pragma weak pthread_mutex_lock
#pragma weak pthread_mutex_unlock
#pragma weak pthread_mutex_trylock
#pragma weak pthread_barrier_wait
#pragma weak pthread_attr_init
#pragma weak pthread_attr_setdetachstate

#define NOTIFY_WOKENUP		1
#define NOTIFY_REMOVED		2
#define NOTIFY_COOKIE_LEN 	32

union notify_cookie {
	struct {
		void (*func) (union sigval);
		union sigval param;
		pthread_attr_t *attr;
	};
	char raw[NOTIFY_COOKIE_LEN];
};


/* This is sent from mq_notify to supervisor thread to request notification */
struct request_data {
	struct sigevent *notification;
	mqd_t mqdes;
	int pipe[2];
};

/* For clarity only - this is sent form supervisor to mq_notify as request ack. */
struct request_ack {
	int retval;
	int err;
};

/* For communication mq_notify->supervisor_thread, and it's (write) lock. */
int supervisor_pipe[2];
pthread_mutex_t supervisor_pipe_lock = PTHREAD_MUTEX_INITIALIZER;

pthread_mutex_t supervisor_lock = PTHREAD_MUTEX_INITIALIZER;
#endif /* SIGEVTHREAD_SUPPORT */

/* check if name is a valid path */
static inline int is_valid_path(const char *name)
{
	int len;

	if (name == NULL)
		goto err_einval;

	len = strnlen(name, PATH_MAX + 1);
	if (len == PATH_MAX + 1)
		goto err_toolong;
		
  	if (len < 1 || name[0] != '/' || strchr(name + 1, '/'))
		goto err_einval;
		
	return 0;

err_einval:
	errno = EINVAL;
	return -1;
err_toolong:
	errno = ENAMETOOLONG;
	return -1;
}

/*
 * kernel interfaces.  We use glibc's syscall(3) instead of the macros
 * _syscall1, _syscall2, etc, as the macros generate compilation errors
 * when mqueue.c is built as a dynamic shared library.
 */
static inline mqd_t __mq_open(const char  *name,
				int oflag, mode_t mode, struct mq_attr* attr)
{
	return syscall(__NR_mq_open, name, oflag, mode, attr);
}

static inline int __mq_unlink(const char *name)
{
	return syscall(__NR_mq_unlink, name);
}

static inline int __mq_notify(mqd_t mqdes, const struct sigevent *notification)
{
	return syscall(__NR_mq_notify, mqdes, notification);
}

static inline int __mq_getsetattr(mqd_t mqdes, const struct mq_attr *mqstat,
				struct mq_attr *omqstat)
{
	return syscall(__NR_mq_getsetattr,  mqdes, mqstat, omqstat);
}

static inline int __mq_timedsend(mqd_t mqdes, const char *msg_ptr,
				size_t msg_len, unsigned int msg_prio,
				const struct timespec *abs_timeout)
{
	return syscall(__NR_mq_timedsend, mqdes, msg_ptr, msg_len,
		msg_prio, abs_timeout);
}

static inline ssize_t __mq_timedreceive(mqd_t mqdes, char *msg_ptr,
				size_t msg_len, unsigned int *msg_prio,
				const struct timespec *abs_timeout)
{
	return syscall(__NR_mq_timedreceive, mqdes, msg_ptr, msg_len,
		msg_prio, abs_timeout);
}

/*
 * application-visible wrappers around the kernel interfaces
 */

mqd_t mq_open(const char *name, int oflag, ...)
{
	unsigned long 	mode;
	struct mq_attr 	*attr;
	va_list 	ap;

	va_start(ap, oflag);
	mode = va_arg(ap, unsigned long);
	attr = va_arg(ap, struct mq_attr *);
	va_end(ap);

	if (is_valid_path(name) < 0)
		return (mqd_t)-1;

	/* omit leading slash */
	return __mq_open(name + 1, oflag, mode, attr);
}

int mq_close(mqd_t mqdes)
{
	return close(mqdes);
}

int mq_unlink(const char *name)
{
	if (is_valid_path(name) < 0)
		return -1;
	
	return __mq_unlink(name+1);
}

int mq_send(mqd_t mqdes, const char *msg_ptr, size_t msg_len,
					unsigned int msg_prio)
{
	return __mq_timedsend(mqdes, msg_ptr, msg_len, msg_prio, NULL);
}

ssize_t mq_receive(mqd_t mqdes, char *msg_ptr, size_t msg_len,
					unsigned int *msg_prio)
{
	return __mq_timedreceive(mqdes, msg_ptr, msg_len, msg_prio, NULL);
}

int mq_timedsend(mqd_t mqdes, const char *msg_ptr, size_t msg_len,
					unsigned int msg_prio,
					const struct timespec *abs_timeout)
{
	return __mq_timedsend(mqdes, msg_ptr, msg_len, msg_prio, abs_timeout);
}

ssize_t mq_timedreceive(mqd_t mqdes, char *msg_ptr, size_t msg_len,
					unsigned int *msg_prio,
					const struct timespec *abs_timeout)
{
	return __mq_timedreceive(mqdes, msg_ptr, msg_len, msg_prio,
		abs_timeout);
}

int mq_getattr(mqd_t mqdes, struct mq_attr *mqstat)
{
	return __mq_getsetattr(mqdes, NULL, mqstat);
}

int mq_setattr(mqd_t mqdes, const struct mq_attr *mqstat,
					struct mq_attr *omqstat)
{
	if (mqstat == NULL) {
		errno = EINVAL;
		return -1;
	}
	return __mq_getsetattr(mqdes, mqstat, omqstat);
}

#ifdef SIGEVTHREAD_SUPPORT

static inline void service_request(int sd)
{
	struct request_data request;
	struct request_ack reply;
	union notify_cookie cookie;

	reply.retval = -1;
	
	if (read(supervisor_pipe[0], &request, sizeof(request)) < 0) {
		fprintf(stderr, "mq_notify BUG: can't read from pipe\n");
		return;
	}
	memset(&cookie, '\0', sizeof(cookie));
	cookie.func = request.notification->sigev_notify_function;
	cookie.param = request.notification->sigev_value;
	if (request.notification->sigev_notify_attributes != NULL) {
		cookie.attr = (pthread_attr_t *)malloc(sizeof (pthread_attr_t));
		if (cookie.attr == NULL)
			return;
		memcpy(cookie.attr, request.notification->sigev_notify_attributes, sizeof(pthread_attr_t));
	}
	request.notification->sigev_signo = sd;
	request.notification->sigev_value.sival_ptr = &cookie;
	if (__mq_notify(request.mqdes, request.notification) < 0) {
		reply.err = errno;
		if (write(request.pipe[1], &reply, sizeof(reply)) < 0)
			fprintf(stderr, "mq_notify BUG: can't write to pipe\n");	
		return;		
	}
	
	reply.retval = 0;
	if (write(request.pipe[1], &reply, sizeof(reply)) < 0)
		fprintf(stderr, "mq_notify BUG: can't write to pipe\n");
}

static void launch(union notify_cookie *cookie)
{
	pthread_attr_t thread_attr, *attr_ptr;
	pthread_t dummy;

	if (cookie->attr == NULL) {
		pthread_attr_init(&thread_attr);
		pthread_attr_setdetachstate(&thread_attr, PTHREAD_CREATE_DETACHED);
		attr_ptr = &thread_attr;
	} else
		attr_ptr = cookie->attr;

	if (pthread_create(&dummy, attr_ptr, (void* (*)(void *))cookie->func, 
		(void *) cookie->param.sival_int))
		fprintf(stderr, "mq_notify ERROR: can't create notification thread\n");

	free(cookie->attr);
}

static int scan_events(int sd)
{
	int retval;
	union notify_cookie cookie;
	
	retval = recv(sd, &cookie, sizeof(cookie), MSG_NOSIGNAL | MSG_WAITALL);
	
	if (retval < 0)
		return retval;

	if (cookie.raw[NOTIFY_COOKIE_LEN - 1] == NOTIFY_WOKENUP)
		launch(&cookie);
	else if (cookie.raw[NOTIFY_COOKIE_LEN - 1] == NOTIFY_REMOVED)
		free(cookie.attr);

	return retval;
}		

static void __error_handler(char *why)
{
	fprintf(stderr, "%s", why);
	close(supervisor_pipe[0]);
	close(supervisor_pipe[1]);
	pthread_mutex_unlock(&supervisor_lock);
}

/* One thread to rule them all...
 * This is started when first mq_notify in process is called and works for all
 * threads in this porcess. It registers in kernel notifications and also 
 * invokes notification threads when kernel tell to do so. */
static void *supervisor_thread(void * arg)
{
	struct notification_list *notifications = NULL;
	struct pollfd poll_array[2];
	int events_no;
	int sd;
	
	sd = socket(PF_NETLINK, SOCK_RAW, 0);
	if (sd < 0) {
		__error_handler("mq_notify FATAL ERROR: can't create socket\n");
		return NULL;
	}

	if (fcntl(sd, F_SETFD, FD_CLOEXEC) != 0) {
		__error_handler("mq_notify FATAL ERROR: can't set close_on_exec\n");
		close(sd);
		return NULL;
	}

	poll_array[0].fd = supervisor_pipe[0];
	poll_array[0].events = POLLIN;
	poll_array[1].fd = sd;
	poll_array[1].events = POLLIN;

	/* wait for notifications (from kernel & library) */
	do {
		events_no = poll(poll_array, 2, -1);
		if (events_no == -1) {
			if (errno == EINTR)
				continue;
			__error_handler("mq_notify FATAL ERROR: can't poll\n");
			return NULL;
		}
		if (poll_array[0].revents & POLLIN)
			service_request(sd);
		
		if (poll_array[1].revents & POLLIN)
			scan_events(sd);
	} while (1);
	
	return NULL;
}

static int create_supervisor()
{
	pthread_t handler_thread;

	if (pipe(supervisor_pipe) < 0)
		return -1;
	
	if (pthread_create(&handler_thread, NULL, supervisor_thread, NULL)) {
		errno = EAGAIN;
		return -1;
	}
	return 0;
}

static int mq_notify_sigevthread(mqd_t mqdes, struct sigevent *notification)
{
	struct request_data request;
	struct request_ack reply;
	int errno_save;

	if (&pthread_create == NULL) {
		errno = ENOSYS;
		return -1;
	}
	if (pthread_mutex_trylock(&supervisor_lock) == 0) {
		if (create_supervisor() == -1) {
			errno_save = errno;
			pthread_mutex_unlock(&supervisor_lock);
			errno = errno_save;
			return -1;
		}
	}

	request.mqdes = mqdes;
	request.notification = notification;
	if (pipe(request.pipe) < 0)
		return -1;

	pthread_mutex_lock(&supervisor_pipe_lock);
	if (write(supervisor_pipe[1], &request, sizeof(request)) < 0) {
		errno_save = errno;
		pthread_mutex_unlock(&supervisor_pipe_lock);
		close(request.pipe[0]);
		close(request.pipe[1]);
		errno = errno_save;
		return -1;
	}
	pthread_mutex_unlock(&supervisor_pipe_lock);
	if (read(request.pipe[0], &reply, sizeof(reply)) < 0) {
		reply.retval = -1;
		reply.err = errno;
	}
	close(request.pipe[0]);
	close(request.pipe[1]);
	if (reply.retval < 0)
		errno = reply.err;
	return reply.retval;
}
#endif


int mq_notify(mqd_t mqdes, const struct sigevent *notification)
{
	if (notification && (notification->sigev_notify == SIGEV_THREAD)) {
#ifdef SIGEVTHREAD_SUPPORT
		return mq_notify_sigevthread(mqdes, notification);
#else
		errno = ENOSYS;
		return -1;
#endif		
	} else
		return __mq_notify(mqdes, notification);

	return 0;
}

